package presentatie;

import logica.Stad;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import static logica.Speler.getSpelerList;
import static logica.Stad.getStadList;

/**
 * In deze klasse zal het tekenwerk gebeuren.
 * Deze klasse bevat het grafisch paneel in de linker helft van de toepassing.
 *
 * @author Sander Spaas
 */
public class TekenPanel {
    private Image achtergrond;
    private JPanel tekenPanel;
    private JLabel coordinatenLabel;

    public JPanel getTekenPanel() {
        return tekenPanel;
    }

    public Image getAchtergrond() {
        if (achtergrond == null) {
            try {
                achtergrond = ImageIO.read(PandemieGui.class.getResource("/europe.png"));
            } catch (IOException e) {
                e.printStackTrace();
                achtergrond = null;
            }
        }
        return achtergrond;
    }

    private void createUIComponents() {
        tekenPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // achtergrond tekenen
                g2.drawImage(getAchtergrond(), 0, 0, null);
                //de coordinaten van de steden verkrijgen
                for (int i = 0; i < getStadList().size(); i++) {
                    int x = getStadList().get(i).getxCoordinaat();
                    int y = getStadList().get(i).getyCoordinaat();
                    //de lijnen effectief gaan tekenen
                    for (int j = 0; j < getStadList().get(i).getBuursteden().size(); j++) {
                        int x2 = getStadList().get((Integer.parseInt(getStadList().get(i).getBuursteden().get(j).toString())) - 1).getxCoordinaat();
                        int y2 = getStadList().get((Integer.parseInt(getStadList().get(i).getBuursteden().get(j).toString())) - 1).getyCoordinaat();
                        g2.setColor(Color.WHITE.darker());
                        g2.setStroke(new BasicStroke(2));
                        g2.drawLine(x, y, x2, y2);
                    }
                }
                for (Stad stad : getStadList()) {
                    //de steden gaan tekenen
                    g2.setColor(stad.getKleur().darker());
                    g2.fillOval(stad.getxCoordinaat() - 12, stad.getyCoordinaat() - 12, 24, 24);
                    g2.setColor(stad.getKleur());
                    g2.fillOval(stad.getxCoordinaat() - 9, stad.getyCoordinaat() - 9, 18, 18);
                    //de namen van de steden gaan tekenen
                    g2.setColor(Color.white);
                    g2.drawString(stad.getNaam(), stad.getxCoordinaat() -15, stad.getyCoordinaat()-12);
                    //kijken of de stad een onderzoekscentrum heeft en dat dan gaan tekenen
                    if (stad.getOnderzoekscentrum()) {
                        g2.setColor(Color.black);
                        g2.fillRect(stad.getxCoordinaat() - 25, stad.getyCoordinaat() - 6, 12, 12);
                        g2.setColor(Color.white);
                        g2.fillRect(stad.getxCoordinaat() - 23, stad.getyCoordinaat() - 4, 8, 8);
                    }
                    //de ziektestenen gaan tekenen
                    int tellerPos2 = 0;
                    for (int j = 0; j < stad.getAantalZiektestenen(); j++) {
                        g2.setColor(stad.getKleur().darker());
                        g2.fillRect(stad.getxCoordinaat() + 3 + tellerPos2, stad.getyCoordinaat() + 4, 15, 15);
                        g2.setColor(stad.getKleur());
                        g2.fillRect(stad.getxCoordinaat() + 6 + tellerPos2, stad.getyCoordinaat() + 7, 9, 9);
                        tellerPos2 = tellerPos2 + 20;
                    }
                    repaint();
                }

                //code om spelers te gaan tekenen
                for (int j = 0; j < getStadList().size(); j++) {
                    getStadList().get(j).setAantalSpelers(0);
                }
                for (int i = 0; i < getSpelerList().size(); i++) {
                    for (int j = 0; j < getStadList().size(); j++) {
                        if (getSpelerList().get(i).getLocatie().equals(getStadList().get(j).getNaam())) {
                            g2.setColor(getSpelerList().get(i).getKleur());
                            g2.fillRect(getStadList().get(j).getxCoordinaat() + 16 + getStadList().get(j).getAantalSpelers(), getStadList().get(j).getyCoordinaat(), 9, 12);
                            g2.fillOval(getStadList().get(j).getxCoordinaat() + 15 + getStadList().get(j).getAantalSpelers(), getStadList().get(j).getyCoordinaat() - 5, 11, 11);
                            getStadList().get(j).setAantalSpelers(getStadList().get(j).getAantalSpelers() + 15);
                        }
                    }

                }


            }

        };

        tekenPanel.addMouseMotionListener(new MouseMotionAdapter() {

            @Override
            public void mouseMoved(MouseEvent e) {
                //coordinaten van de muis gaan tonen
                coordinatenLabel.setText(e.getX() + "," + e.getY());

            }
        });
        tekenPanel.setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
    }

}
