package presentatie;

import data.DataLayerJDBC;
import logica.Speler;
import logica.Stad;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static logica.Infectiekaart.*;
import static logica.Speler.*;
import static logica.Stad.*;

/**
 * Dit is een Gui voor het spel Pandemie, een opdracht voor het vak Object Orientation & Database Concepts - 2020-2021
 *
 * @author Sander Spaas
 */
public class PandemieGui {
    private TekenPanel tekenPanelForm;
    private JPanel tekenPanel;
    protected JPanel mainPanel;
    private JTextArea logTextArea;
    private JTextArea rolBeschrijving;
    private JPanel sidePanel;
    private JButton trekInfectiekaartButton;
    private JLabel nogNietGetrokken;
    private JLabel getrokken;
    private JLabel naamStad;
    private JButton volgendeSpeler;
    private JLabel rolSpeler;
    private JProgressBar aantalGetrokken;
    private JProgressBar resterendeActies;
    private JLabel spelerNaam;
    private JProgressBar uitbraken;
    private JProgressBar uitgeroeideZiektes;

    List<Integer> mogelijkeLocaties = new ArrayList<>();
    final int[] stappenTeller = {0};
    private int aantalGetrokkenGetal = 0;
    final int[] spelerTeller = {0};
    int aantalUitgeroeid = 0;
    final int[] uitbrakenTeller = {0};
    int paneTeller = 0;
    final DataLayerJDBC[] dataLayer = {new DataLayerJDBC("pandemie")};

    public void spelerVerzetten(MouseEvent e, final int[] spelerTeller, int max) {
        Point punt = e.getPoint();
        for (int j = 0; j < getStadList().size(); j++) {
            //lijst van buursteden en eventueele steden met researchstation gaan maken
            if (spelerList.get(spelerTeller[0]).getLocatie().equals(getStadList().get(j).getNaam())) {
                mogelijkeLocaties.addAll(getStadList().get(j).getBuurstedenComplete());
                for (int k = 0; k < getStadList().size(); k++) {
                    if (getStadList().get(k).getOnderzoekscentrum()) {
                        System.out.println(getStadList().get(k).getNaam() + " heeft een onderzoekscentrum");
                        if (!mogelijkeLocaties.contains(getStadList().get(k).getID())) {
                            if (!spelerList.get(spelerTeller[0]).getLocatie().equals(getStadList().get(k).getNaam())) {
                                mogelijkeLocaties.add(getStadList().get(k).getID());
                            }
                        }
                    }
                }
            }
            if (spelerList.get(spelerTeller[0]).getLocatie().equals(getStadList().get(j).getNaam())) {
                //de speler zicht laten verzetten
                System.out.println("dit zijn de mogelijke steden waar je naartoe kan gaan");
                for (int locatie : mogelijkeLocaties) {
                    System.out.println(getStadList().get(locatie - 1).getNaam() + ": " + locatie);
                }
                for (int idBuur : mogelijkeLocaties) {
                    int xStad = getStadList().get(idBuur - 1).getxCoordinaat();
                    int yStad = getStadList().get(idBuur - 1).getyCoordinaat();

                    if ((punt.getX() > xStad - 9 && punt.getX() < xStad + 9) && (punt.getY() > yStad - 9 && punt.getY() < yStad + 9)) {
                        spelerList.get(spelerTeller[0]).setLocatie(getStadList().get(idBuur - 1).getNaam());
                        System.out.println(spelerList.get(spelerTeller[0]).getLocatie());
                        stappenTeller[0]++;
                        resterendeActies.setMinimum(0);
                        resterendeActies.setMaximum(max);
                        showActions();
                    }
                }
            }
            mogelijkeLocaties.clear();
        }
    }

    //de info van de huidige speler aan zet updaten
    public void setInfoSpeler() {
        spelerNaam.setForeground(spelerList.get(spelerTeller[0]).getKleur());
        spelerNaam.setText(spelerList.get(spelerTeller[0]).getNaam());
        rolSpeler.setText(spelerList.get(spelerTeller[0]).getRol().getNaam());
        rolBeschrijving.setText(spelerList.get(spelerTeller[0]).getRol().getBeschrijving());
    }


    //gaan kijken of de speler gewonnen/verloren is of dat het spel gewoon mag blijven doorgaan
    public void gewonnenVerloren() {
        //de actie voor als de speler verloren is
        if (uitbrakenTeller[0] >= 8 && paneTeller < 1) {
            paneTeller++;
            JOptionPane.showOptionDialog(null, "Je bent verloren: er zijn 8 of meer uitbraken geweest! \n De mensheid is verloren en je heldhaftige daden zullen al snel vergeten worden, aangezien er niemand meer zal zijn om ze te gedenken. \n Europa vervalt in complete anarchie en de laatste maanden tot de volledige verwoesting zijn verschrikkelijk.", "Verloren!", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
            //de einddata in de database gaan steken
            stuurDoor(false);
            System.exit(0);
        }
        if (aantalUitgeroeid == 4) { //de actie voor als de speler gewonnen is
            stuurDoor(true);
            JFrame frame = new JFrame("Gewonnen! - Sander Spaas");
            frame.setContentPane(new GewonnenForm(frame).winPanel);
            frame.pack();
            frame.setVisible(true);
        }
    }

    //dingen naar de database sturen
    public void stuurDoor(boolean gewonnen){
        //de einddata in de database gaan steken
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Calendar cal = Calendar.getInstance();
        String datumTijd = dateFormat.format(cal.getTime());
        try {
            dataLayer[0].spelEinde(datumTijd, gewonnen);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    //de progressbars updaten
    private void showActions() {
        resterendeActies.setStringPainted(true);
        resterendeActies.setValue(stappenTeller[0]);
        uitgeroeideZiektes.setMaximum(4);
        uitgeroeideZiektes.setStringPainted(true);
        uitgeroeideZiektes.setValue(aantalUitgeroeid);
    }

    //tekenpaneel gaan aanmaken
    private void createUIComponents() {
        tekenPanelForm = new TekenPanel();
        tekenPanel = tekenPanelForm.getTekenPanel();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Pandemie - Sander Spaas");
        if (frame.getTitle().contains("student"))
            JOptionPane.showMessageDialog(frame, "Voeg in de titel van het frame je eigen naam toe \nom deze melding te vermijden.", "Titel nog niet aangepast", JOptionPane.WARNING_MESSAGE);
        frame.setContentPane(new PandemieGui(frame).mainPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public PandemieGui(JFrame hoofdframe) {
        final boolean[] kaartenGetrokken = {false};
        final boolean[] stappenGezet = {false};

        //de infectiekaarten gaan aanmaken en gaan kaffelen
        maakKaarten();
        shuffle(infectiekaarten);
        //de data voor de beginnende speler gaan juistzetten
        setInfoSpeler();

        //de ziektes in aparte lists gaan steken
        sorteerOpZiekte();

        //beginstad gaan bijhouden voor later
        setBeginStad(getSpelerList().get(0).getLocatie());

        //het trekken van de kaarten in het begin van de beurt en dan het toekennen van ziektestenen
        trekInfectiekaartButton.addActionListener(e -> {
            if (aantalGetrokkenGetal < 3) {
                String naam = trekKaart().getNaamStad();
                logTextArea.append("De kaart van de stad: " + naam + " is getrokken.\n");
                naamStad.setText(naam);
                nogNietGetrokken.setText("Gedekte infectiestapel: " + getAantalKaarten() + "/" + getStadList().size());
                getrokken.setText("Getrokken infectiekaarten: " + (getStadList().size() - getAantalKaarten()) + "/" + getStadList().size());

                //de ziektestenen gaan toevoegen
                //alle steden gaan nakijken
                for (int i = 0; i < getStadList().size(); i++) {
                    if (getStadList().get(i).getAantalZiektestenen() == 3) {
                        //de uitbraken gaan tellen
                        uitbrakenTeller[0]++;
                        uitbraken.setMaximum(8);
                        uitbraken.setStringPainted(true);
                        uitbraken.setValue(uitbrakenTeller[0]);
                    }
                    //nu gaan we kijken naar alle steden als aantal stenen == 3 dan gaan we die spreiden
                    for (int j = 0; j < getStadList().get(i).getBuurstedenComplete().size(); j++) {
                        int buurstadId = getStadList().get(i).getBuurstedenComplete().get(j);
                        if (getStadList().get(i).getAantalZiektestenen() == 3) {
                            if (getStadList().get(buurstadId - 1).getAantalZiektestenen() < 3) {
                                //gaan kijken of de quarantine specialist het gaat voorkomen
                                boolean voegtoe = true;
                                for (Speler speler : spelerList) {
                                    if (speler.getRol().getId() == 5 && speler.getLocatie().equals(getStadList().get(buurstadId - 1).getNaam())) {
                                        logTextArea.append("De " + speler.getRol().getNaam() + " heeft een uitbraak in " + getStadList().get(buurstadId - 1).getNaam() + " voorkomen! \n");
                                        voegtoe = false;
                                        break;
                                    }
                                }
                                if (voegtoe) {
                                    if (!getStadList().get(buurstadId - 1).isUitgeroeid()) {
                                        getStadList().get(buurstadId - 1).setAantalZiektestenen((getStadList().get(buurstadId - 1).getAantalZiektestenen() + 1));
                                        gewonnenVerloren();
                                        //alle steden van die kleur op actief zetten
                                        for (int id : welkeKleur(buurstadId - 1)) {
                                            getStadList().get(id - 1).setActief(true);
                                            System.out.println(getStadList().get(id - 1).getNaam() + ": " + getStadList().get(id - 1).isActief());
                                        }
                                    } else {
                                        logTextArea.append("De ziekte in de stad: " + getStadList().get(buurstadId - 1).getNaam() + " is al uitgeroeid! \n");
                                    }
                                }
                            }
                        }
                    }
                }
                //voor individuele steden
                for (int i = 0; i < getStadList().size(); i++) {
                    if (getStadList().get(i).getNaam().equals(naam)) {
                        //gaan kijken of de stad effectief een ziektesteen krijgt
                        if (getStadList().get(i).getAantalZiektestenen() < 3) {
                            //gaan kijken of de quarantine specialist het gaat voorkomen
                            boolean voegtoe = true;
                            for (Speler speler : spelerList) {
                                if (speler.getRol().getId() == 5 && speler.getLocatie().equals(naam)) {
                                    logTextArea.append("De " + speler.getRol().getNaam() + " heeft een uitbraak in " + getStadList().get(i).getNaam() + " voorkomen! \n");
                                    voegtoe = false;
                                    break;
                                }
                            }
                            if (voegtoe) {
                                if (!getStadList().get(i).isUitgeroeid()) {
                                    //de stad zelf krijgt een ziektesteen bij
                                    System.out.println("het id van de speler: " + spelerList.get(spelerTeller[0]).getRol().getId() + " de locatie van de speler: " + spelerList.get(spelerTeller[0]).getLocatie() + " de getrokken stad: " + naam);
                                    getStadList().get(i).setAantalZiektestenen(getStadList().get(i).getAantalZiektestenen() + 1);
                                    gewonnenVerloren();
                                    //alle steden van die kleur op actief zetten
                                    for (int id : welkeKleur(i)) {
                                        getStadList().get(id - 1).setActief(true);
                                        System.out.println(getStadList().get(id - 1).getNaam() + ": " + getStadList().get(id - 1).isActief());
                                    }
                                } else {
                                    logTextArea.append("De ziekte in de stad: " + getStadList().get(i).getNaam() + " is al uitgeroeid! \n");
                                }

                            }
                        }
                    }
                }
                aantalGetrokkenGetal++;
                aantalGetrokken.setMaximum(3);
                aantalGetrokken.setStringPainted(true);
                aantalGetrokken.setValue(aantalGetrokkenGetal);
                if (aantalGetrokkenGetal == 3) {
                    trekInfectiekaartButton.setEnabled(false);
                    logTextArea.append("Je hebt je 3 kaarten getrokken. \n");
                    kaartenGetrokken[0] = true;
                }
            }
        });

        //movement system
        logTextArea.append(spelerList.get(spelerTeller[0]).getNaam() + " is aan de beurt.\n");
        //het bewegen van de speler
        final int[] tussensCheck = {0};
        tekenPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                //de actie/acties van de speler
                int max = 3;
                boolean uitgeroeid = true;
                switch (spelerList.get(spelerTeller[0]).getRol().getId()) {
                    case 1 -> { //containement specialist
                        if (stappenTeller[0] < 2 && kaartenGetrokken[0]) {
                            tussensCheck[0]++;
                            max = 2;
                            spelerVerzetten(e, spelerTeller, max);
                            //een steen in elke stad gaan verwijderen
                            for (int i = 0; i < getStadList().size(); i++) {
                                if (spelerList.get(spelerTeller[0]).getLocatie().equals(getStadList().get(i).getNaam())) {
                                    if (getStadList().get(i).getAantalZiektestenen() > 1) {
                                        getStadList().get(i).setAantalZiektestenen(getStadList().get(i).getAantalZiektestenen() - 1);
                                        logTextArea.append("De " + spelerList.get(spelerTeller[0]).getRol().getNaam() + " een ziektesteen van " + getStadList().get(i).getNaam() + " verwijderd!.\n ");
                                        resterendeActies.setMaximum(2);
                                        showActions();
                                        //gaan nakijken of de steden van die kleur nog stenen hebben indien allemaal nee --> ziekte uitgeroeid
                                        for (int id : welkeKleur(i)) {
                                            if (getStadList().get(id - 1).getAantalZiektestenen() != 0) {
                                                uitgeroeid = false;
                                            }
                                        }
                                        if (uitgeroeid) {
                                            logTextArea.append("De mensheid hebben de ziektes een ware slag toegebracht door de " + getStadList().get(i).getKleurNaam() + "E ziekte uit te roeien! \n");
                                            aantalUitgeroeid++;
                                            gewonnenVerloren();
                                            for (int id : welkeKleur(i)) {
                                                getStadList().get(id - 1).setUitgeroeid(true);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (tussensCheck[0] >= 2) {
                            stappenGezet[0] = true;
                        }
                    }
                    case 2 -> { //operations expert
                        if (stappenTeller[0] < 2 && kaartenGetrokken[0]) {
                            spelerVerzetten(e, spelerTeller, 2);
                            tussensCheck[0]++;
                            showActions();
                        }
                        if (stappenTeller[0] == 2 && kaartenGetrokken[0]) {
                            tussensCheck[0]++;
                            for (int i = 0; i < getStadList().size(); i++) {
                                if (spelerList.get(spelerTeller[0]).getLocatie().equals(getStadList().get(i).getNaam())) {
                                    if (!getStadList().get(i).getOnderzoekscentrum()) {
                                        getStadList().get(i).setOnderzoekscentrum(1);
                                        logTextArea.append("Onderzoekstation gebouwd in: " + getStadList().get(i).getNaam() + ".\n");
                                    }
                                }
                            }
                            showActions();
                            gewonnenVerloren();
                        }
                        if (tussensCheck[0] >= 3) {
                            stappenGezet[0] = true;
                            showActions();
                        }
                    }
                    case 3 -> { //medic
                        if (stappenTeller[0] < 2 && kaartenGetrokken[0]) {
                            tussensCheck[0]++;
                            spelerVerzetten(e, spelerTeller, 2);
                        }
                        if (stappenTeller[0] == 2 && kaartenGetrokken[0]) {
                            tussensCheck[0]++;
                            for (int i = 0; i < getStadList().size(); i++) {
                                if (spelerList.get(spelerTeller[0]).getLocatie().equals(getStadList().get(i).getNaam())) {
                                    if (getStadList().get(i).getAantalZiektestenen() != 0) {
                                        getStadList().get(i).setAantalZiektestenen(0);
                                        logTextArea.setText(logTextArea.getText() + "De medic heeft " + getStadList().get(i).getNaam() + " genezen!.\n");
                                        //gaan nakijken of de steden van die kleur nog stenen hebben indien allemaal nee --> ziekte uitgeroeid
                                        for (int id : welkeKleur(i)) {
                                            if (getStadList().get(id - 1).getAantalZiektestenen() != 0) {
                                                uitgeroeid = false;
                                            }
                                        }
                                        if (uitgeroeid) {
                                            logTextArea.append("De mensheid hebben de ziektes een ware slag toegebracht door de " + getStadList().get(i).getKleurNaam() + "E ziekte uit te roeien! \n");
                                            aantalUitgeroeid++;
                                            gewonnenVerloren();
                                            for (int id : welkeKleur(i)) {
                                                getStadList().get(id - 1).setUitgeroeid(true);
                                            }
                                        }
                                    }
                                    stappenTeller[0]++;
                                    showActions();
                                }
                            }
                        }
                        if (tussensCheck[0] >= 3) {
                            stappenGezet[0] = true;
                        }
                    }
                    case 4 -> { //Generalist
                        if (stappenTeller[0] < 3 && kaartenGetrokken[0]) {
                            tussensCheck[0]++;
                            spelerVerzetten(e, spelerTeller, 3);
                        }
                        if (stappenTeller[0] == 3 && kaartenGetrokken[0]) {
                            spelerVerzetten(e, spelerTeller, 4);
                            for (int i = 0; i < getStadList().size(); i++) {
                                if (spelerList.get(spelerTeller[0]).getLocatie().equals(getStadList().get(i).getNaam())) {
                                    if (getStadList().get(i).getAantalZiektestenen() != 0) {
                                        getStadList().get(i).setAantalZiektestenen(getStadList().get(i).getAantalZiektestenen() - 1);
                                        logTextArea.append("De " + spelerList.get(spelerTeller[0]).getRol().getNaam() + " een ziektesteen van " + getStadList().get(i).getNaam() + " verwijderd!.\n ");
                                        //gaan nakijken of de steden van die kleur nog stenen hebben indien allemaal nee --> ziekte uitgeroeid
                                        for (int id : welkeKleur(i)) {
                                            if (getStadList().get(id - 1).getAantalZiektestenen() != 0) {
                                                uitgeroeid = false;
                                            }
                                        }
                                        if (uitgeroeid) {
                                            logTextArea.append("De mensheid hebben de ziektes een ware slag toegebracht door de " + getStadList().get(i).getKleurNaam() + "E ziekte uit te roeien! \n");
                                            aantalUitgeroeid++;
                                            gewonnenVerloren();
                                            for (int id : welkeKleur(i)) {
                                                getStadList().get(id - 1).setUitgeroeid(true);
                                            }
                                        }
                                    }
                                    showActions();
                                }
                            }
                            stappenTeller[0]++;
                        }
                        if (tussensCheck[0] >= 3) {
                            stappenGezet[0] = true;
                        }
                    }
                    case 5 -> { //Quarantine Specialist
                        if (stappenTeller[0] < 2 && kaartenGetrokken[0]) {
                            tussensCheck[0]++;
                            spelerVerzetten(e, spelerTeller, max);
                        }
                        if (stappenTeller[0] == 2 && kaartenGetrokken[0]) {
                            tussensCheck[0]++;
                            for (int i = 0; i < getStadList().size(); i++) {
                                if (spelerList.get(spelerTeller[0]).getLocatie().equals(getStadList().get(i).getNaam())) {
                                    if (getStadList().get(i).getAantalZiektestenen() != 0) {
                                        getStadList().get(i).setAantalZiektestenen(getStadList().get(i).getAantalZiektestenen() - 1);
                                        logTextArea.append("De quarantine specialist heeft een ziektesteen van " + getStadList().get(i).getNaam() + " verwijderd!.\n ");
                                        aantalUitgeroeid++;
                                        gewonnenVerloren();
                                        //gaan nakijken of de steden van die kleur nog stenen hebben indien allemaal nee --> ziekte uitgeroeid
                                        for (int id : welkeKleur(i)) {
                                            if (getStadList().get(id - 1).getAantalZiektestenen() != 0) {
                                                uitgeroeid = false;
                                            }
                                        }
                                        if (uitgeroeid) {
                                            logTextArea.append("De mensheid hebben de ziektes een ware slag toegebracht door de " + getStadList().get(i).getKleurNaam() + "E ziekte uit te roeien! \n");
                                            for (int id : welkeKleur(i)) {
                                                getStadList().get(id - 1).setUitgeroeid(true);
                                            }
                                        }
                                    }
                                    logTextArea.append("!!!ALERT!!! " + getStadList().get(i).getNaam() + " is onder een tijdelijke quarantaine  geplaatst !!!ALERT!!!\n ");
                                    stappenTeller[0]++;
                                    showActions();
                                }
                            }
                        }
                        if (tussensCheck[0] >= 3) {
                            stappenGezet[0] = true;
                        }
                    }
                    default -> {
                        if (stappenTeller[0] < 2 && kaartenGetrokken[0]) {
                            tussensCheck[0]++;
                            spelerVerzetten(e, spelerTeller, max);
                        }
                        if (stappenTeller[0] == 2 && kaartenGetrokken[0]) {
                            tussensCheck[0]++;
                            for (int i = 0; i < getStadList().size(); i++) {
                                if (spelerList.get(spelerTeller[0]).getLocatie().equals(getStadList().get(i).getNaam())) {
                                    if (getStadList().get(i).getAantalZiektestenen() != 0) {
                                        getStadList().get(i).setAantalZiektestenen(getStadList().get(i).getAantalZiektestenen() - 1);
                                        logTextArea.append("De " + spelerList.get(spelerTeller[0]).getRol().getNaam() + " een ziektesteen van " + getStadList().get(i).getNaam() + " verwijderd!.\n ");
                                        //gaan nakijken of de steden van die kleur nog stenen hebben indien allemaal nee --> ziekte uitgeroeid
                                        for (int id : welkeKleur(i)) {
                                            if (getStadList().get(id - 1).getAantalZiektestenen() != 0) {
                                                uitgeroeid = false;
                                            }
                                        }
                                        if (uitgeroeid) {
                                            logTextArea.append("De mensheid hebben de ziektes een ware slag toegebracht door de " + getStadList().get(i).getKleurNaam() + "E ziekte uit te roeien! \n");
                                            aantalUitgeroeid++;
                                            gewonnenVerloren();
                                            for (int id : welkeKleur(i)) {
                                                getStadList().get(id - 1).setUitgeroeid(true);
                                            }
                                        }
                                    }
                                    stappenTeller[0]++;
                                    showActions();
                                }
                            }
                        }
                        if (tussensCheck[0] >= 3) {
                            stappenGezet[0] = true;
                        }
                    }
                }
            }
        });

        //gaan kijken of de vorige speler alles heeft gedaan indien wel alle nodige data gaan resetten en de speleraanzet veranderen
        volgendeSpeler.addActionListener(e -> {
            if (kaartenGetrokken[0] && stappenGezet[0]) {
                System.out.println("de volgende speler is aan zet");
                aantalGetrokkenGetal = 0;
                stappenTeller[0] = 0;
                kaartenGetrokken[0] = false;
                stappenGezet[0] = false;
                tussensCheck[0] = 0;
                showActions();
                trekInfectiekaartButton.setEnabled(true);
                spelerTeller[0]++;
                //de spelers gaan loopen als de laatste gespeeld heeft
                if (spelerTeller[0] == spelerList.size()) {
                    spelerTeller[0] = 0;
                }
                //de juiste data voor de speler gaan tonen
                setInfoSpeler();
            } else {
                logTextArea.append("De vorige speler is nog niet klaar met al zijn/haar acties. \n");
            }
        });

    }

}
