package presentatie;

import data.DataLayerJDBC;
import logica.Stad;

import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static logica.Stad.getBeginStad;
import static logica.Stad.getStadList;

/**
 * Pandemie : GewonnenForm
 *
 * @author Sander Spaas
 * @version 2/06/2021
 */
public class GewonnenForm {
    private JComboBox<Object> stedenmetOnderzoek;
    protected JPanel winPanel;
    private JButton okeButton;
    private JTextArea kiesEenStadInTextArea;
    private JTextArea overwinning;

    public GewonnenForm(JFrame winPanel) {
        final DataLayerJDBC[] dataLayer = {new DataLayerJDBC("pandemie")};
        List<String> stedenOnderzoeksCentra = new ArrayList<>();
        for (Stad stad: getStadList()) {
            if(stad.getOnderzoekscentrum()){
                stedenOnderzoeksCentra.add(stad.getNaam());
            }
        }
        //de startstad gaan verwijderen uit de lijst van mogelijke steden om te kiezen
        stedenOnderzoeksCentra.removeIf(stad -> stad.equals(getBeginStad()));

        stedenmetOnderzoek.setModel(new DefaultComboBoxModel<>(stedenOnderzoeksCentra.toArray()));
        okeButton.addActionListener(e -> {
            try {
                dataLayer[0].gekozenCentrumUpdate(stedenmetOnderzoek.getSelectedItem().toString(), 1);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            System.exit(0);
        });
    }
}
