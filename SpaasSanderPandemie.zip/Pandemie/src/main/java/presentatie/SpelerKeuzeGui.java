package presentatie;

import data.DataLayerJDBC;
import logica.*;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static logica.Rollen.rollenList;
import static logica.Speler.*;
import static logica.Stad.getStadList;
import static logica.Stad.getStedenOnderzoekcentrum;


/**
 * Pandemie : SpelerKeuzeGui
 *
 * @author Sander Spaas
 * @version 26/05/2021
 */
public class SpelerKeuzeGui {
    private JComboBox startlocatie;
    private JComboBox keuzeSpeler;
    private JTextField naamSpeler;
    private JComboBox rolSpeler;
    private JComboBox kleurSpeler;
    private JButton continueButton;
    private JPanel KeuzeMain;
    private JButton saveSpelerButton;
    private JLabel feedbackField;
    private JTextArea rolBeschrijving;

    public SpelerKeuzeGui(JFrame vorigframe) {
        //data van alle onderzoekscentra gaan halen
        final DataLayerJDBC[] dataLayer = {new DataLayerJDBC("pandemie")};
        try {
            dataLayer[0].getSteden();
            dataLayer[0].getRollen();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        List<String> rollenNamen = new ArrayList<>();
        List<String> rollenBeschrijving = new ArrayList<>();
        String[] Spelers = new String[]{"Speler 1", "Speler 2", "Speler 3", "Speler 4"};
        KleurSpeler[] Kleuren = new KleurSpeler[]{KleurSpeler.ROZE, KleurSpeler.BLAUW, KleurSpeler.BRUIN, KleurSpeler.WIT};

        for (Rollen rollen : rollenList) {
            rollenNamen.add(rollen.getNaam());
            rollenBeschrijving.add(rollen.getBeschrijving());
        }
        //volgende keer die rollenlist in de formgui krijgen dan zien om die data in het speleropbject te steken
        //data in de comboBox steken
        startlocatie.setModel(new DefaultComboBoxModel<>(getStedenOnderzoekcentrum().toArray()));
        keuzeSpeler.setModel(new DefaultComboBoxModel<>(Spelers));
        rolSpeler.setModel(new DefaultComboBoxModel<>(rollenNamen.toArray()));
        kleurSpeler.setModel(new DefaultComboBoxModel<>(Kleuren));
        rolBeschrijving.setText(rollenBeschrijving.get(0));


        //code die de data van de speler gaat saven
        saveSpelerButton.addActionListener(e -> {
            if (naamSpeler.getText().equals("")) {
                feedbackField.setForeground(Color.RED);
                feedbackField.setText("Geef een naam op.");
                throw new IllegalArgumentException("Geef een naam op");
            } else {
                //De waarden gaan uitlezen
                String spelerNummer = (String) keuzeSpeler.getSelectedItem();
                String naam = naamSpeler.getText();
                KleurSpeler kleur = (KleurSpeler) kleurSpeler.getSelectedItem();
                String rolnaam = (String) rolSpeler.getSelectedItem();
                String startLocatie = (String) startlocatie.getSelectedItem();
                for (int i = 0; i < rollenBeschrijving.size(); i++) {
                    if (rolnaam.equals(rollenList.get(i).getNaam())) {
                        //de input gaan controleren
                        checkInput(spelerNummer, naam, kleur, rollenList.get(i), getSpelerList(), startLocatie);
                        //object gaan aanmaken en aan de lijst toevoegen
                        Speler speler = new Speler(spelerNummer, naam, kleur, rollenList.get(i), startLocatie);
                        setSpelerList(speler);
                        System.out.println("objectje aangemaakt!");
                        setInfo(getSpelerList());
                        feedbackField.setForeground(Color.decode("#2DC64F"));
                        feedbackField.setText("Speler opgeslagen!");

                    }
                }

                //code die de huidige objecten in de lijst gestructureerd gaat weergeven
                for (int i = 0; i < getSpelerList().size(); i++) {
                    System.out.println(getSpelerList().get(i).toString());
                    System.out.println("----------------------------");
                }
                System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxx");
            }
        });

        //Bij het selecteren van een nieuwe speler bv. SPELER_1 gaat de info over deze getoond worden
        keuzeSpeler.addActionListener(e -> setInfo(getSpelerList()));

        //De beschrijving gaan updaten naargelang welke rol geslecteerd is
        rolSpeler.addActionListener(e -> {
            String rolnaam = (String) rolSpeler.getSelectedItem();
            for (int i = 0; i < rollenBeschrijving.size(); i++) {
                if (rolnaam.equals(rollenList.get(i).getNaam())) {
                    rolBeschrijving.setText(rollenBeschrijving.get(i));
                }
            }
        });

        //de code die het wisselen van tussen de 2 GUI's gaat regelen
        continueButton.addActionListener(e -> {
            //pas MINAANTALSPELERS aan om het minimum aantal spelers te veranderen
            final int MINAANTALSPELERS = 2;
            //gaan nakijken of er genoeg spelerobjecten zijn aangemaakt
            if (getSpelerList().size() >= MINAANTALSPELERS) {
                //de begindata in de database gaan steken
                DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                Calendar cal = Calendar.getInstance();
                String datumTijd = dateFormat.format(cal.getTime());
                try {
                    dataLayer[0].spelToevoegen(datumTijd);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                //de spelerdata er in gaan steken
                for (Speler speler : getSpelerList()) {
                    try {
                        dataLayer[0].spelerToevoegen(speler);
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                }
                //de beginstad een onderzoekscentrum gaan geven
                for (Stad stad: getStadList()) {
                    if (stad.getNaam().equals(spelerList.get(0).getLocatie())){
                        stad.setOnderzoekscentrum(1);
                    }
                }
                //de pandemieGui gaan openenen
                JFrame frame = new JFrame("Pandemie - Sander Spaas");
                frame.setContentPane(new PandemieGui(frame).mainPanel);
                frame.pack();
                frame.setVisible(true);

                //de keuzeGUI gaan sluiten
                vorigframe.dispose();
            } else {
                feedbackField.setForeground(Color.RED);
                feedbackField.setText("Nog niet genoeg spelers aangemaakt: " + getSpelerList().size() + "/" + MINAANTALSPELERS);
            }
        });
    }

    public void checkInput(String spelerNummer, String naam, KleurSpeler kleur, Rollen rol, List<Speler> spelers, String startLocatie) {
        for (Speler speler : spelers) {
            if (!speler.getSpelerNummer().equals(spelerNummer)) {
                //nakijken of de startlocatie niet hetzelfde is
                if (!speler.getLocatie().equals(startLocatie)) {
                    feedbackField.setForeground(Color.RED);
                    feedbackField.setText("Startlocatie verschillend");
                    throw new IllegalArgumentException("Startlocatie verschillend");
                }
                //nakijken of de naam al in gebruik is
                if (speler.getNaam().equals(naam)) {
                    feedbackField.setForeground(Color.RED);
                    feedbackField.setText("Naam al gekozen");
                    throw new IllegalArgumentException("Naam al gekozen");
                }
                //nakijken of de rol al in gebruik is
                if (speler.getRol().getNaam().equals(rol.getNaam())) {
                    feedbackField.setForeground(Color.RED);
                    feedbackField.setText("Rol al gekozen");
                    throw new IllegalArgumentException("Rol al gekozen");
                }
                //nakijken of de kleur al in gebruik is
                if (speler.getKleurNaam().equals(kleur)) {
                    feedbackField.setForeground(Color.RED);
                    feedbackField.setText("Kleur al gekozen");
                    throw new IllegalArgumentException("Kleur al gekozen");
                }
            }
        }
        //als de speler al data heeft zijn we gaan nakijken of de nieuwe data al niet gekozen was en anders verwijderen we het object en maken we een nieuw aan
        for (int i = 0; i < spelers.size(); i++) {
            if (spelers.get(i).getSpelerNummer().equals(spelerNummer)) {
                removeFromList(i);
                setInfo(getSpelerList());
            }
        }
    }

    public void setInfo(List<Speler> spelerLijst) {
        String spelerNummer = (String) keuzeSpeler.getSelectedItem();
        feedbackField.setText("");
        naamSpeler.setText("");
        rolSpeler.setSelectedIndex(0);
        kleurSpeler.setSelectedIndex(0);
        for (int i = 0; i < spelerLijst.size(); i++) {
            if (spelerLijst.get(i).getSpelerNummer().equals(spelerNummer)) {
                feedbackField.setText("");
                naamSpeler.setText(spelerLijst.get(i).getNaam());
                rolSpeler.setSelectedItem(spelerLijst.get(i).getRol().getNaam());
                kleurSpeler.setSelectedItem(spelerLijst.get(i).getKleurNaam());
                startlocatie.setSelectedItem(spelerLijst.get(i).getLocatie());
            }
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Keuzemenu Pandemie - Sander Spaas");
        frame.setContentPane(new SpelerKeuzeGui(frame).KeuzeMain);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);
        frame.setVisible(true);
    }


}

