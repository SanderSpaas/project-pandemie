package logica;

/**
 * Pandemie : Kleur
 *
 * @author Sander Spaas
 * @version 26/05/2021
 */
public enum Kleur {
    WIT,
    ROOD,
    BRUIN,
    GEEL,
    ZWART,
    BLAUW,
    ROZE
}