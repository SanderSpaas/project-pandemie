package logica;

import java.util.ArrayList;
import java.util.List;

/**
 * Pandemie : Rollen
 *
 * @author Sander Spaas
 * @version 26/05/2021
 */
public class Rollen {
    private final int id;
    private final String naam;
    private final String beschrijving;
    public static List<Rollen> rollenList = new ArrayList<>();

    public Rollen(int id, String naamRol, String beschrijving){
        this.id = id;
        this.naam = naamRol;
        this.beschrijving = beschrijving;
    }
    static public void setRolList(Rollen rol) {
        rollenList.add(rol);
    }

    public int getId() {
        return id;
    }

    public String getNaam() {
        return naam;
    }

    public String getBeschrijving() {
        return beschrijving;
    }


}
