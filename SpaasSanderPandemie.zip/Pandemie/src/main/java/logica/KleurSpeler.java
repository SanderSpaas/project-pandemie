package logica;

/**
 * Pandemie : KleurSpeler
 *
 * @author Sander Spaas
 * @version 2/06/2021
 */
public enum KleurSpeler {
    WIT,
    ROZE,
    BRUIN,
    BLAUW,
}
