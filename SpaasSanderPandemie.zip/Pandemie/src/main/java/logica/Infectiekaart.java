package logica;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static logica.Speler.spelerList;
import static logica.Stad.getStadList;

/**
 * Pandemie : Infectiekaarten
 *
 * @author Sander Spaas
 * @version 28/05/2021
 */
public class Infectiekaart {
    private final String naamStad;
    public static List<Infectiekaart> infectiekaarten = new ArrayList<>();
    private static int aantalGetrokken = 0;
    private static List<Infectiekaart> getrokkenKaarten = new ArrayList<>();

    public Infectiekaart(String naamStad) {
        this.naamStad = naamStad;
    }

    static public void maakKaarten() {
        for (int i = 0; i < getStadList().size(); i++) {
            Infectiekaart kaart = new Infectiekaart(getStadList().get(i).getNaam());
            infectiekaarten.add(kaart);
        }
    }

    static public void shuffle(List<Infectiekaart> kaarten) {
        Collections.shuffle(kaarten);
        System.out.println("kaarten geschud");
    }

    static public Infectiekaart trekKaart() {
        Infectiekaart kaart;
        if (aantalGetrokken < (3*spelerList.size())){
            kaart = infectiekaarten.get(infectiekaarten.size()-1);
            infectiekaarten.remove(infectiekaarten.size()-1);
            getrokkenKaarten.add(kaart);
            aantalGetrokken++;
            return kaart;
        }
        else{
            shuffle(getrokkenKaarten);
            infectiekaarten.addAll(getrokkenKaarten);
            getrokkenKaarten.clear();
            aantalGetrokken = 0;
            kaart = trekKaart();
            return kaart;
        }
    }

    static public int getAantalKaarten() {
        return infectiekaarten.size();
    }

    public String getNaamStad() {
        return naamStad;
    }
}
