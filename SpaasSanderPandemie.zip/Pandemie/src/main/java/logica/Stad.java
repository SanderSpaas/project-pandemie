package logica;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Pandemie: Stad
 *
 * @author Sander Spaas
 * @version 26/05/2021
 */
public class Stad {
    private final int ID;
    private final String naam;
    private final Kleur kleur;
    private final int xCoordinaat;
    private final int yCoordinaat;
    private int onderzoekscentrum;
    private final List<Integer> buursteden;
    private final List<Integer> buurstedenComplete;
    private boolean isActief;
    private boolean isUitgeroeid;
    private int aantalZiektestenen;
    private int aantalSpelers;
    private static final List<Stad> stedenList = new ArrayList<>();
    private static final List<Integer> ziekteLijstZwart = new ArrayList<>();
    private static final List<Integer> ziekteLijstBlauw = new ArrayList<>();
    private static final List<Integer> ziekteLijstGeel = new ArrayList<>();
    private static final List<Integer> ziekteLijstRood = new ArrayList<>();
    private static final List<String> stedenOnderzoekcentrum = new ArrayList<>();
    private static String beginStad;

    public Stad(int ID, String naam, Kleur kleur, int x, int y, List<Integer> buursteden, List<Integer> buurstedenComplete) {
        this.ID = ID;
        this.naam = naam;
        this.kleur = kleur;
        this.xCoordinaat = x;
        this.yCoordinaat = y;
        this.onderzoekscentrum = 0;
        this.buursteden = buursteden;
        this.buurstedenComplete = buurstedenComplete;
        this.aantalZiektestenen = 0;
        this.isActief = false;
        this.isUitgeroeid = false;
        this.aantalSpelers = 0;
    }

    static public void setStadList(Stad stad) {
        stedenList.add(stad);
    }

    public void setAantalZiektestenen(int aantalZiektestenen) {
        this.aantalZiektestenen = aantalZiektestenen;
    }

    public void setOnderzoekscentrum(int onderzoekscentrum) {
        this.onderzoekscentrum = onderzoekscentrum;
    }

    static public void sorteerOpZiekte() {
        for (Stad stad : getStadList()) {
            if (stad.getKleurNaam() == Kleur.ROOD) {
                ziekteLijstRood.add(stad.getID());
            } else if (stad.getKleurNaam() == Kleur.GEEL) {
                ziekteLijstGeel.add(stad.getID());
            } else if (stad.getKleurNaam() == Kleur.BLAUW) {
                ziekteLijstBlauw.add(stad.getID());
            } else if (stad.getKleurNaam() == Kleur.ZWART) {
                ziekteLijstZwart.add(stad.getID());
            }
        }
    }

    static public List<Integer> welkeKleur(int stadTeller) {
        if (getStadList().get(stadTeller).getKleurNaam() == Kleur.GEEL) {
            return getZiekteLijstGeel();
        } else if (getStadList().get(stadTeller).getKleurNaam() == Kleur.ROOD) {
            return getZiekteLijstRood();
        } else if (getStadList().get(stadTeller).getKleurNaam() == Kleur.BLAUW) {
            return getZiekteLijstBlauw();
        } else if (getStadList().get(stadTeller).getKleurNaam() == Kleur.ZWART) {
            return getZiekteLijstZwart();
        }
        return null;
    }

    static public List<Stad> getStadList() {
        return stedenList;
    }

    public String getNaam() {
        return this.naam;
    }

    public Color getKleur() {
        if (this.kleur == Kleur.ROOD) {
            return Color.decode("#D84444");
        }
        if (this.kleur == Kleur.BLAUW) {
            return Color.decode("#1A94D5");
        }
        if (this.kleur == Kleur.GEEL) {
            return Color.decode("#FFCE45");
        }
        if (this.kleur == Kleur.ZWART) {
            return Color.decode("#464646");
        }
        return Color.BLACK;
    }

    public Kleur getKleurNaam() {
        return this.kleur;
    }

    public int getxCoordinaat() {
        return this.xCoordinaat;
    }

    public int getyCoordinaat() {
        return this.yCoordinaat;
    }

    public boolean getOnderzoekscentrum() {
        return this.onderzoekscentrum != 0;
    }

    public int getID() {
        return this.ID;
    }

    public List<Integer> getBuursteden() {
        return buursteden;
    }

    public List<Integer> getBuurstedenComplete() {
        return buurstedenComplete;
    }

    public int getAantalZiektestenen() {
        return aantalZiektestenen;
    }

    public int getAantalSpelers() {
        return aantalSpelers;
    }


    public boolean isActief() {
        return isActief;
    }

    public boolean isUitgeroeid() {
        return isUitgeroeid;
    }


    public void setActief(boolean actief) {
        isActief = actief;
    }

    public void setUitgeroeid(boolean uitgeroeid) {
        isUitgeroeid = uitgeroeid;
    }

    public void setAantalSpelers(int aantalSpelers) {
        this.aantalSpelers = aantalSpelers;
    }

    public static void setStedenOnderzoekcentrum(String stadId) {
        stedenOnderzoekcentrum.add(stadId);
    }

    public static List<String> getStedenOnderzoekcentrum() {
        return stedenOnderzoekcentrum;
    }

    public static List<Integer> getZiekteLijstZwart() {
        return ziekteLijstZwart;
    }

    public static List<Integer> getZiekteLijstBlauw() {
        return ziekteLijstBlauw;
    }

    public static List<Integer> getZiekteLijstGeel() {
        return ziekteLijstGeel;
    }

    public static List<Integer> getZiekteLijstRood() {
        return ziekteLijstRood;
    }

    public static String getBeginStad() {
        return beginStad;
    }

    public static void setBeginStad(String stad) {
        beginStad = stad;
    }
}
