package logica;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Pandemie : Speler
 *
 * @author Sander Spaas
 * @version 26/05/2021
 */
public class Speler {
    private final String spelerNummer;
    private final String naam;
    private final KleurSpeler kleur;
    private final Rollen rol;
    private String locatie;
    public static List<Speler> spelerList = new ArrayList<>();

    public Speler(String spelerNummer, String naam, KleurSpeler kleur, Rollen rol, String locatie){
        this.spelerNummer = spelerNummer;
        this.naam = naam;
        this.kleur = kleur;
        this.rol = rol;
        this.locatie = locatie;
    }

    static public void setSpelerList(Speler speler) {
        spelerList.add(speler);
    }

    static public void removeFromList(int index) {
        spelerList.remove(index);
    }

    static public List<Speler> getSpelerList() {
        return spelerList;
    }

    public Color getKleur() {
        if (this.kleur == KleurSpeler.ROZE){
            return Color.decode("#D45AC7");
        }
        if (this.kleur == KleurSpeler.BLAUW){
            return Color.decode("#1A94D5");
        }
        if (this.kleur == KleurSpeler.BRUIN){
            return Color.decode("#964B00");
        }
        if (this.kleur == KleurSpeler.WIT){
            return Color.white;
        }
        return Color.BLACK;
    }

    public KleurSpeler getKleurNaam() {
       return this.kleur;
    }

    public String getNaam() {
        return naam;
    }


    public Rollen getRol() {
        return rol;
    }

    public String getSpelerNummer() {
        return spelerNummer;
    }

    public String getLocatie() {
        return locatie;
    }

    public void setLocatie(String locatie) {
        this.locatie = locatie;
    }

    @Override
    public String toString() {
        return "Speler{" +
                "spelerNummer='" + spelerNummer + '\'' +
                ", naam='" + naam + '\'' +
                ", kleur=" + kleur +
                ", rol=" + rol +
                ", locatie='" + locatie + '\'' +
                '}';
    }
}

