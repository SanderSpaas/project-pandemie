package data;

import logica.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import static logica.Rollen.setRolList;
import static logica.Stad.*;

/**
 * Pandemie: DataLayer
 *
 * @author Sander Spaas
 * @version 20/05/2021
 */
public class DataLayerJDBC {
    private String databaseNaam;
    private final String gebruikersnaam = "pandemie";
    private final String wachtwoord = "Azerty123!";
    private Connection connectie;


    public DataLayerJDBC(String databaseNaam) {
        this.databaseNaam = databaseNaam;
        startConnection();
    }

    private void startConnection() {
        try {
            this.connectie = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + databaseNaam + "?serverTimezone=UTC&allowMultiQueries=true", gebruikersnaam, wachtwoord);

        } catch (SQLException error) {
            Logger.getLogger(DataLayerJDBC.class.getName()).log(Level.SEVERE, null, error);
        }
    }


    public void getSteden() throws SQLException {
        Statement stmt = null;
        try {
            stmt = this.connectie.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);

            ResultSet rs = stmt.executeQuery("SELECT * FROM Steden");

            while (rs.next()) {
                int id = rs.getInt("id");
                String naam = rs.getString("naam");
                Kleur kleur = Kleur.valueOf(rs.getString("kleur"));
                int x = rs.getInt("x");
                int y = rs.getInt("y");
                int onderzoekscentrum = rs.getInt(6);
                if (onderzoekscentrum == 1) {
                    setStedenOnderzoekcentrum(naam);
                }
                List<Integer> buren = getBuursteden(id);
                List<Integer> burenComplete = getBurenComplete(id);
                Stad stad = new Stad(id, naam, kleur, x, y, buren, burenComplete);
                setStadList(stad);
            }

        } catch (SQLException ex) {
            Logger.getLogger(DataLayerJDBC.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    public List<Integer> getBuursteden(int stadId) throws SQLException {
        List<Integer> burenList = new ArrayList<>();
        Statement stmt = null;
        try {
            stmt = this.connectie.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery("SELECT stad1_id, stad2_id from verbindingen");
            while (rs.next()) {
                int stad1 = rs.getInt("stad1_id");
                int stad2 = rs.getInt("stad2_id");
                if (stad1 == stadId) {
                    burenList.add(stad2);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataLayerJDBC.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
        return burenList;
    }

    public List<Integer> getBurenComplete(int id) throws SQLException {
        ArrayList<Integer> buurstedenListComplete = new ArrayList<>();
        String query2 = "select stad1_id, stad2_id from connecties";
        try {
            Statement stmt = connectie.createStatement();
            ResultSet rs = stmt.executeQuery(query2);
            while (rs.next()) {
                int idStad1 = rs.getInt("stad1_id");
                int idStad2 = rs.getInt("stad2_id");
                if (idStad1 == id) {
                    buurstedenListComplete.add(idStad2);
                }
                if (idStad2 == id) {
                    buurstedenListComplete.add(idStad1);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataLayerJDBC.class.getName()).log(Level.SEVERE, null, ex);
        }
        return buurstedenListComplete;
    }

    public void getRollen() throws SQLException {
        Statement stmt = null;

        try {
            stmt = this.connectie.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery("select * from rollen;");

            while (rs.next()) {
                int id = rs.getInt("id");
                String rol = rs.getString("naam");
                String beschrijving = rs.getString("beschrijving");
                Rollen rollen = new Rollen(id, rol, beschrijving);
                setRolList(rollen);
            }

        } catch (SQLException ex) {
            Logger.getLogger(DataLayerJDBC.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }


    public void gekozenCentrumUpdate(String naam, int onderzoekCentrum) throws SQLException {
        Statement stmt = null;
        try {
            stmt = connectie.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
            ResultSet uprs = stmt.executeQuery("select * FROM steden WHERE naam = '" + naam + "';");
            while (uprs.next()) {
                uprs.updateInt("onderzoeksCentrum", onderzoekCentrum);
                uprs.updateRow();
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataLayerJDBC.class.getName()).log(Level.SEVERE, null, ex);

        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    public void spelerToevoegen(Speler speler) throws SQLException {
        PreparedStatement stmt = null;
        try {
            stmt = connectie.prepareStatement("INSERT INTO spelers (spel_id, kleur, rol_id, naam) VALUES (?,?,?,?)");
            stmt.setInt(1, (huidigId() - 1));
            System.out.println(speler.getKleurNaam());
            stmt.setString(2, String.valueOf(speler.getKleurNaam()));
            stmt.setInt(3, speler.getRol().getId());
            stmt.setString(4, speler.getNaam());
            stmt.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(DataLayerJDBC.class.getName()).log(Level.SEVERE, null, ex);

        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    public int huidigId() {
        int vrijId = 0;
        Statement stmt = null;
        try {
            stmt = this.connectie.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery("select id from spellen;");
            while (rs.next()) {
                vrijId = rs.getInt("id");
            }
            vrijId++;
        } catch (SQLException ex) {
            Logger.getLogger(DataLayerJDBC.class.getName()).log(Level.SEVERE, null, ex);
        }
        return vrijId;
    }

    public void spelToevoegen(String startTijd) throws SQLException {
        PreparedStatement stmt = null;
        try {
            stmt = connectie.prepareStatement("INSERT INTO spellen (id, start) VALUES (?,?)");
            stmt.setInt(1, huidigId());
            stmt.setString(2, startTijd);
            stmt.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(DataLayerJDBC.class.getName()).log(Level.SEVERE, null, ex);

        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    public void spelEinde(String eindTijd, boolean gewonnen) throws SQLException {
        Statement stmt = null;
        try {
            stmt = connectie.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
            ResultSet uprs = stmt.executeQuery("Select * FROM spellen WHERE id = '" + (huidigId() - 1) + "'");
            while (uprs.next()) {
                uprs.updateString("einde", eindTijd);
                uprs.updateBoolean("gewonnen", gewonnen);
                uprs.updateRow();
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataLayerJDBC.class.getName()).log(Level.SEVERE, null, ex);

        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }
}
