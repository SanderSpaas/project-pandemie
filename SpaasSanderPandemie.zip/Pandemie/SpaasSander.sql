CREATE DATABASE  IF NOT EXISTS `pandemie` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `pandemie`;
-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: pandemie
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `connecties`
--

DROP TABLE IF EXISTS `connecties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `connecties` (
  `stad1_id` int unsigned NOT NULL,
  `stad2_id` int unsigned NOT NULL,
  PRIMARY KEY (`stad1_id`,`stad2_id`),
  KEY `fk_steden_has_steden_steden2_idx` (`stad2_id`),
  KEY `fk_steden_has_steden_steden1_idx` (`stad1_id`),
  CONSTRAINT `fk_steden_has_steden_steden1` FOREIGN KEY (`stad1_id`) REFERENCES `steden` (`id`),
  CONSTRAINT `fk_steden_has_steden_steden2` FOREIGN KEY (`stad2_id`) REFERENCES `steden` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `connecties`
--

LOCK TABLES `connecties` WRITE;
/*!40000 ALTER TABLE `connecties` DISABLE KEYS */;
INSERT INTO `connecties` VALUES (22,1),(10,2),(23,2),(1,3),(4,3),(9,4),(3,5),(4,5),(25,5),(7,6),(14,6),(16,6),(19,8),(20,8),(1,10),(5,10),(1,11),(2,11),(11,12),(14,12),(22,12),(11,13),(17,13),(13,14),(8,15),(20,15),(7,16),(14,16),(17,16),(24,17),(7,18),(17,18),(19,18),(24,18),(7,19),(21,19),(9,20),(25,20),(8,21),(15,21),(11,22),(5,23),(15,23),(25,23),(2,24),(23,24),(9,25);
/*!40000 ALTER TABLE `connecties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rollen`
--

DROP TABLE IF EXISTS `rollen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rollen` (
  `id` int NOT NULL AUTO_INCREMENT,
  `naam` varchar(45) NOT NULL,
  `beschrijving` tinytext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `naam_UNIQUE` (`naam`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rollen`
--

LOCK TABLES `rollen` WRITE;
/*!40000 ALTER TABLE `rollen` DISABLE KEYS */;
INSERT INTO `rollen` VALUES (1,'Containment Specialist','Verwijder een steen in elke stad waar je komt op voorwaarde dat deze stad twee of drie ziektestenen bevat.'),(2,'Operations Expert','Bouw een onderzoeksstation in de stad waar je beurt eindigt indien deze stad nog geen onderzeksstation heeft. Je neemt geen ziektesteen weg.'),(3,'Medic','Verwijder alle stenen in de stad waar je eindigt.'),(4,'Generalist','Doe vier acties per beurt, dus drie stappen en één ziektesteen verwijderen. '),(5,'Quarantine Specialist','Er kunnen geen stenen meer bijkomen in de stad waar je je bevindt.');
/*!40000 ALTER TABLE `rollen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spelers`
--

DROP TABLE IF EXISTS `spelers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `spelers` (
  `spel_id` int NOT NULL,
  `kleur` enum('BRUIN','WIT','BLAUW','ROZE') NOT NULL,
  `rol_id` int NOT NULL,
  `naam` varchar(45) NOT NULL,
  PRIMARY KEY (`spel_id`,`kleur`),
  KEY `fk_spelers_spellen1_idx` (`spel_id`),
  KEY `fk_spelers_rollen1_idx` (`rol_id`) /*!80000 INVISIBLE */,
  CONSTRAINT `fk_spelers_rollen1` FOREIGN KEY (`rol_id`) REFERENCES `rollen` (`id`),
  CONSTRAINT `fk_spelers_spellen1` FOREIGN KEY (`spel_id`) REFERENCES `spellen` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spelers`
--

LOCK TABLES `spelers` WRITE;
/*!40000 ALTER TABLE `spelers` DISABLE KEYS */;
INSERT INTO `spelers` VALUES (1,'BLAUW',2,'Amelia'),(1,'ROZE',1,'sander'),(2,'BRUIN',3,'Dr. Bruinbeer'),(2,'WIT',4,'Mr. Giraffe'),(3,'BRUIN',4,'Ash'),(3,'BLAUW',3,'Berend'),(3,'ROZE',2,'Gert'),(4,'WIT',4,'Sara'),(4,'BLAUW',3,'Piet'),(4,'ROZE',2,'PandemiePro'),(5,'WIT',4,'MrGeneral'),(5,'BLAUW',3,'TomyBoyyy'),(5,'ROZE',2,'NerdyNerd'),(6,'BRUIN',3,'Mr. MooOoOOo'),(6,'WIT',4,'Captain Kirk'),(6,'ROZE',2,'KittyCat'),(7,'BRUIN',3,'Mr. MooOoOOo'),(7,'WIT',4,'Captain Kirk'),(7,'ROZE',2,'KittyCat'),(8,'BRUIN',3,'Mr. MoooOOooOO'),(8,'BLAUW',4,'Captain Kirk'),(8,'ROZE',2,'KittyKatty'),(9,'BRUIN',3,'ikOokEchtNietHoor'),(9,'ROZE',1,'VooralNietValsGespeeld');
/*!40000 ALTER TABLE `spelers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spellen`
--

DROP TABLE IF EXISTS `spellen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `spellen` (
  `id` int NOT NULL AUTO_INCREMENT,
  `start` datetime NOT NULL,
  `einde` datetime DEFAULT NULL,
  `gewonnen` tinyint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spellen`
--

LOCK TABLES `spellen` WRITE;
/*!40000 ALTER TABLE `spellen` DISABLE KEYS */;
INSERT INTO `spellen` VALUES (1,'2021-06-03 14:34:19','2021-06-03 14:35:05',0),(2,'2021-06-03 15:49:45','2021-06-03 15:51:34',0),(3,'2021-06-03 15:56:47','2021-06-03 15:58:28',0),(4,'2021-06-03 16:02:17','2021-06-03 16:04:06',0),(5,'2021-06-03 16:05:50','2021-06-03 16:06:49',1),(6,'2021-06-03 16:16:07',NULL,NULL),(7,'2021-06-03 16:16:08',NULL,NULL),(8,'2021-06-03 16:17:18','2021-06-03 16:18:36',0),(9,'2021-06-03 16:21:17','2021-06-03 16:21:35',1);
/*!40000 ALTER TABLE `spellen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `steden`
--

DROP TABLE IF EXISTS `steden`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `steden` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `naam` varchar(45) NOT NULL,
  `kleur` enum('GEEL','ROOD','BLAUW','ZWART') NOT NULL,
  `x` int NOT NULL,
  `y` int NOT NULL,
  `onderzoekscentrum` tinyint(3) unsigned zerofill NOT NULL DEFAULT '000' COMMENT 'onderzoekscentrum mogelijk bij de start',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `steden`
--

LOCK TABLES `steden` WRITE;
/*!40000 ALTER TABLE `steden` DISABLE KEYS */;
INSERT INTO `steden` VALUES (1,'Londen','BLAUW',349,579,000),(2,'Essen','BLAUW',456,592,000),(3,'Parijs','BLAUW',385,650,000),(4,'Madrid','GEEL',306,801,000),(5,'Milaan','BLAUW',476,716,000),(6,'St. Petersburg','ZWART',758,387,000),(7,'Moskou','ZWART',857,481,000),(8,'Istanbul','GEEL',743,794,000),(9,'Algiers','GEEL',395,869,000),(10,'Brussel','BLAUW',415,608,001),(11,'Oslo','ROOD',495,394,000),(12,'Tromsø','ROOD',609,80,000),(13,'Stockholm','ROOD',596,406,000),(14,'Helsinki','ROOD',680,368,000),(15,'Sofia','ZWART',669,759,000),(16,'Tallinn','ROOD',699,418,000),(17,'Riga','ZWART',677,462,000),(18,'Minsk','ZWART',725,542,001),(19,'Kiev','ZWART',761,613,000),(20,'Athene','GEEL',675,846,000),(21,'Boekarest','ZWART',701,728,000),(22,'Reykjavik','ROOD',71,260,000),(23,'Wenen','BLAUW',569,658,000),(24,'Warschau','ZWART',624,570,000),(25,'Rome','GEEL',528,775,000);
/*!40000 ALTER TABLE `steden` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `verbindingen`
--

DROP TABLE IF EXISTS `verbindingen`;
/*!50001 DROP VIEW IF EXISTS `verbindingen`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `verbindingen` AS SELECT 
 1 AS `steden1_id`,
 1 AS `steden1_naam`,
 1 AS `steden1_kleur`,
 1 AS `stad1_id`,
 1 AS `steden2_id`,
 1 AS `steden2_naam`,
 1 AS `steden2_kleur`,
 1 AS `stad2_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `verbindingen`
--

/*!50001 DROP VIEW IF EXISTS `verbindingen`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `verbindingen` AS select `steden`.`id` AS `steden1_id`,`steden`.`naam` AS `steden1_naam`,`steden`.`kleur` AS `steden1_kleur`,`connecties`.`stad1_id` AS `stad1_id`,`steden`.`id` AS `steden2_id`,`steden`.`naam` AS `steden2_naam`,`steden`.`kleur` AS `steden2_kleur`,`connecties`.`stad2_id` AS `stad2_id` from (`steden` join `connecties` on((`steden`.`id` = `connecties`.`stad1_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-03 16:45:35
